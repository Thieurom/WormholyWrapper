//
//  NSURLSessionConfiguration+Wormholy.h
//  Wormholy-SDK
//
//  Created by Paolo Musolino on 18/01/18.
//  Copyright © 2018 Wormholy. All rights reserved.
//

//@class Wormholy;
//
//@interface NSURLSessionConfiguration (Wormholy)
//
//@end

